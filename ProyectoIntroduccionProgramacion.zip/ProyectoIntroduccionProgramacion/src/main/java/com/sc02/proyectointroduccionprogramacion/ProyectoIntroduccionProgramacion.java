/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */


package com.sc02.proyectointroduccionprogramacion;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author andre
 */
public class ProyectoIntroduccionProgramacion {

    public static void main(String[] args) {
        boolean salir = false;
        do {
            String entrada = JOptionPane.showInputDialog("Ingrese una opción: "
                    + "\n(1) Tipo de pago"
                    + "\n(2) Contribuyente"
                    + "\n(3) Impuesto"
                    + "\n(4) Aporte"
                    + "\n(5) Pago"
                    + "\n(6) Reporte"
                    + "\n(7) Salir");
            int op = Integer.parseInt(entrada);
            switch (op) {
                case 1:
                    JOptionPane.showMessageDialog(null,"1) Bienvenindo a la seccion de tipo de pago");
                    JOptionPane.showMessageDialog(null,"-----------------------------------------------");

                    break;

                case 2:
                    JOptionPane.showMessageDialog(null,"2) Bienvenindo a la seccion de Contrubuyente");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null,"3) Bienvenindo a la seccion de Impuesto");
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null,"4) Bienvenindo a la seccion de Aporte");
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,"5) Bienvenindo a la seccion de Pago");
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null,"6) Bienvenindo a la seccion de Reporte");
                    break;

                case 7:
                    JOptionPane.showMessageDialog(null,"7) Salir");
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null,"Ingrese un dato correcto");
            }

        } while (!salir);
    }
}
